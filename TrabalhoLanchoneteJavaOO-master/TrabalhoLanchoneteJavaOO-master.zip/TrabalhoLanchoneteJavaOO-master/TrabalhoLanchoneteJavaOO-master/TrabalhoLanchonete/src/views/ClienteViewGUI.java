package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ClienteViewGUI extends JFrame {
    private JTextField codigoField, nomeField, cpfField;
    private JButton cadastrarButton, exibirButton, alterarButton, excluirButton, pesquisarButton;
    private JTextArea outputArea;

    public ClienteViewGUI() {
        super("Gerenciar Clientes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Initialize components
        codigoField = new JTextField(10);
        nomeField = new JTextField(20);
        cpfField = new JTextField(20);
        cadastrarButton = new JButton("Cadastrar");
        exibirButton = new JButton("Exibir");
        alterarButton = new JButton("Alterar");
        excluirButton = new JButton("Excluir");
        pesquisarButton = new JButton("Pesquisar");
        outputArea = new JTextArea(10, 30);
        outputArea.setEditable(false);

        // Create panels
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        inputPanel.add(new JLabel("Código:"));
        inputPanel.add(codigoField);
        inputPanel.add(new JLabel("Nome:"));
        inputPanel.add(nomeField);
        inputPanel.add(new JLabel("CPF:"));
        inputPanel.add(cpfField);
        inputPanel.add(cadastrarButton);
        inputPanel.add(exibirButton);
        inputPanel.add(alterarButton);
        inputPanel.add(excluirButton);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(pesquisarButton);

        JScrollPane scrollPane = new JScrollPane(outputArea);

        // Add components to the frame
        getContentPane().add(inputPanel, BorderLayout.NORTH);
        getContentPane().add(buttonPanel, BorderLayout.CENTER);
        getContentPane().add(scrollPane, BorderLayout.SOUTH);

        // Add action listeners
        cadastrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cadastrarCliente();
            }
        });

        exibirButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exibirClientes();
            }
        });

        alterarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                alterarCliente();
            }
        });

        excluirButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                excluirCliente();
            }
        });

        pesquisarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pesquisarClientePorCodigo();
            }
        });

        setVisible(true);
    }

    private void cadastrarCliente() {
        int codigo = Integer.parseInt(codigoField.getText());
        String nome = nomeField.getText();
        String cpf = cpfField.getText();
        ClientesController.adicionarCliente(codigo, nome, cpf);
        outputArea.setText("Cliente cadastrado com sucesso!");
    }

    private void exibirClientes() {
        outputArea.setText("");
        for (Cliente cliente : BancoDadosLanchonete.getTabelaCliente()) {
            outputArea.append("Código: " + cliente.getCodigo() + "\n");
            outputArea.append("Nome: " + cliente.getNome() + "\n");
            outputArea.append("CPF: " + cliente.getCpf() + "\n\n");
        }
    }

    private void alterarCliente() {
        int codigo = Integer.parseInt(codigoField.getText());
        String nome = nomeField.getText();
        String cpf = cpfField.getText();
        if (ClientesController.alterarCliente(codigo, nome, cpf)) {
            outputArea.setText("Cliente alterado com sucesso!");
        } else {
            outputArea.setText("Cliente não encontrado!");
        }
    }

    private void excluirCliente() {
        int codigo = Integer.parseInt(codigoField.getText());
        if (ClientesController.excluirCliente(codigo)) {
            outputArea.setText("Cliente excluído com sucesso!");
        } else {
            outputArea.setText("Cliente não encontrado!");
        }
    }

    private void pesquisarClientePorCodigo() {
        int codigo = Integer.parseInt(codigoField.getText());
        Cliente cliente = ClientesController.buscarPorCodigo(codigo);
        if (cliente != null) {
            outputArea.setText("Código: " + cliente.getCodigo() + "\n");
            outputArea.append("Nome: " + cliente.getNome() + "\n");
            outputArea.append("CPF: " + cliente.getCpf() + "\n");
        } else {
            outputArea.setText("Cliente não encontrado!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ClienteViewGUI();
            }
        });
    }
}
